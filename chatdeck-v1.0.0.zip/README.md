# CryptoFlow – One Page Template
#### Preview

 - [Demo](https://themewagon.github.io/cryptoflow/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/cryptoflow/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/cryptoflow.git
```
2. Install Dependencies
```
npm i
```
3. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

## Author 
```
Design and code is completely written by codescandy and development team. 
```

## License

 - Design and Code is Copyright &copy; <a href="url" target="_blank">codescandy</a>
 - Licensed cover under [MIT]
 - Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
